module.exports = {
  BOT_TOKEN: "TOKEN BOT",
  OWNER_ID: ["8474115703"],
};